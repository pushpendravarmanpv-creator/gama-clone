import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  LayoutDashboard, 
  FileText, 
  Image, 
  Presentation, 
  BarChart3, 
  CreditCard,
  Zap
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "AI Text Generation", href: "/ai-text", icon: FileText },
  { name: "AI Image Generation", href: "/ai-image", icon: Image },
  { name: "Presentations", href: "/presentations", icon: Presentation },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
  { name: "Subscription", href: "/subscription", icon: CreditCard },
];

export function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col slide-in">
      {/* Logo Section */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 gradient-bg rounded-lg flex items-center justify-center">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-xl font-bold text-foreground">AI Master Studio</h1>
        </div>
      </div>
      
      {/* Navigation Menu */}
      <nav className="flex-1 p-4 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          
          return (
            <Link key={item.name} href={item.href}>
              <a 
                className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                  isActive 
                    ? "bg-primary text-primary-foreground" 
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.name}</span>
              </a>
            </Link>
          );
        })}
      </nav>
      
      {/* User Profile Section */}
      {user && (
        <div className="p-4 border-t border-border">
          <Link href="/profile">
            <a 
              className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted transition-colors"
              data-testid="nav-profile"
            >
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-white font-semibold">
                {user.firstName ? user.firstName.charAt(0) : user.email.charAt(0)}
                {user.lastName ? user.lastName.charAt(0) : user.email.charAt(1)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {user.firstName && user.lastName 
                    ? `${user.firstName} ${user.lastName}` 
                    : user.username}
                </p>
                <div className="flex items-center space-x-2">
                  <p className="text-xs text-muted-foreground capitalize">{user.plan} Plan</p>
                  {user.plan === "pro" && (
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-accent text-accent-foreground">
                      Pro
                    </span>
                  )}
                </div>
              </div>
            </a>
          </Link>
        </div>
      )}
    </div>
  );
}
