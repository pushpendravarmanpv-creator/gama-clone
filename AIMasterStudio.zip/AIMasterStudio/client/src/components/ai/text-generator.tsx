import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Zap } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const promptTypes = [
  { value: "creative", label: "Creative Writing" },
  { value: "business", label: "Business Content" },
  { value: "technical", label: "Technical Documentation" },
  { value: "marketing", label: "Marketing Copy" },
];

export function TextGenerator() {
  const [prompt, setPrompt] = useState("");
  const [promptType, setPromptType] = useState("creative");
  const [result, setResult] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const generateText = useMutation({
    mutationFn: async (data: { prompt: string; type: string }) => {
      const response = await apiRequest("POST", "/api/ai/generate-text", data);
      return response.json();
    },
    onSuccess: (data) => {
      setResult(data.content);
      queryClient.invalidateQueries({ queryKey: ["/api/ai/generations"] });
      toast({
        title: "Text Generated",
        description: "Your AI-generated content is ready!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate text",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt Required",
        description: "Please enter a prompt to generate text",
        variant: "destructive",
      });
      return;
    }

    generateText.mutate({ prompt, type: promptType });
  };

  return (
    <div className="space-y-6">
      <Card className="hover-lift">
        <CardHeader>
          <CardTitle className="flex items-center space-x-3">
            <div className="w-8 h-8 gradient-bg rounded-lg flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span>AI Text Generation</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Enter your prompt here..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            className="resize-none"
            data-testid="input-text-prompt"
          />
          
          <div className="flex items-center justify-between">
            <Select value={promptType} onValueChange={setPromptType}>
              <SelectTrigger className="w-48" data-testid="select-prompt-type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {promptTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button 
              onClick={handleGenerate}
              disabled={generateText.isPending}
              className="gradient-bg hover:opacity-90"
              data-testid="button-generate-text"
            >
              {generateText.isPending ? "Generating..." : "Generate"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {result && (
        <Card className="fade-in">
          <CardHeader>
            <CardTitle>Generated Content</CardTitle>
          </CardHeader>
          <CardContent>
            <div 
              className="whitespace-pre-wrap text-sm text-foreground"
              data-testid="text-generated-content"
            >
              {result}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
