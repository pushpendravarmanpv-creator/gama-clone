import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Image as ImageIcon } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const providers = [
  { value: "openai", label: "DALL-E 3" },
  { value: "stability", label: "Stability AI" },
];

const sizes = [
  { value: "1024x1024", label: "1024×1024" },
  { value: "1024x1792", label: "1024×1792" },
  { value: "1792x1024", label: "1792×1024" },
];

export function ImageGenerator() {
  const [prompt, setPrompt] = useState("");
  const [provider, setProvider] = useState("openai");
  const [size, setSize] = useState("1024x1024");
  const [generatedImage, setGeneratedImage] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const generateImage = useMutation({
    mutationFn: async (data: { prompt: string; provider: string; size: string }) => {
      const response = await apiRequest("POST", "/api/ai/generate-image", data);
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedImage(data.url);
      queryClient.invalidateQueries({ queryKey: ["/api/ai/generations"] });
      toast({
        title: "Image Generated",
        description: "Your AI-generated image is ready!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate image",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt Required",
        description: "Please describe the image you want to create",
        variant: "destructive",
      });
      return;
    }

    generateImage.mutate({ prompt, provider, size });
  };

  return (
    <div className="space-y-6">
      <Card className="hover-lift">
        <CardHeader>
          <CardTitle className="flex items-center space-x-3">
            <div className="w-8 h-8 gradient-bg rounded-lg flex items-center justify-center">
              <ImageIcon className="w-4 h-4 text-white" />
            </div>
            <span>AI Image Generation</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="Describe the image you want to create..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            className="resize-none"
            data-testid="input-image-prompt"
          />
          
          <div className="flex items-center justify-between">
            <div className="flex space-x-4">
              <Select value={provider} onValueChange={setProvider}>
                <SelectTrigger className="w-32" data-testid="select-image-provider">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {providers.map((p) => (
                    <SelectItem key={p.value} value={p.value}>
                      {p.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={size} onValueChange={setSize}>
                <SelectTrigger className="w-32" data-testid="select-image-size">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sizes.map((s) => (
                    <SelectItem key={s.value} value={s.value}>
                      {s.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <Button 
              onClick={handleGenerate}
              disabled={generateImage.isPending}
              className="gradient-bg hover:opacity-90"
              data-testid="button-generate-image"
            >
              {generateImage.isPending ? "Generating..." : "Generate"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {generatedImage && (
        <Card className="fade-in">
          <CardHeader>
            <CardTitle>Generated Image</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center">
              <img 
                src={generatedImage} 
                alt="Generated AI image"
                className="max-w-full h-auto rounded-lg border border-border"
                data-testid="img-generated-image"
              />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
