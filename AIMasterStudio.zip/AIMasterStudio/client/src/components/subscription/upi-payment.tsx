import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const UPI_IDS = [
  "8815958253@ibl",
  "8815958253-3@ybl"
];

export function UPIPayment() {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const { toast } = useToast();

  const copyToClipboard = async (upiId: string) => {
    try {
      await navigator.clipboard.writeText(upiId);
      setCopiedId(upiId);
      setTimeout(() => setCopiedId(null), 2000);
      toast({
        title: "UPI ID Copied",
        description: `${upiId} copied to clipboard`,
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy UPI ID",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>UPI Payment (India)</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Send ₹2,400 (approx $29) to any of the UPI IDs below:
        </p>
        
        <div className="space-y-3">
          {UPI_IDS.map((upiId) => (
            <div 
              key={upiId}
              className="flex items-center justify-between p-3 border rounded-lg"
            >
              <code className="text-sm font-mono">{upiId}</code>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(upiId)}
                className="ml-2"
                data-testid={`button-copy-upi-${upiId}`}
              >
                {copiedId === upiId ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
          ))}
        </div>
        
        <div className="mt-4 p-4 bg-muted rounded-lg">
          <p className="text-sm text-muted-foreground">
            <strong>Note:</strong> After making the payment, please send a screenshot 
            to support@aimasterstudio.com for manual verification and account upgrade.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
