import { apiRequest } from "./queryClient";
import { User } from "@shared/schema";

export const authApi = {
  async getCurrentUser(): Promise<User | null> {
    try {
      const response = await apiRequest("GET", "/api/auth/me");
      return await response.json();
    } catch {
      return null;
    }
  },

  async signInWithGoogle(): Promise<{ url: string }> {
    const response = await apiRequest("GET", "/api/auth/google");
    return await response.json();
  },

  async logout(): Promise<void> {
    await apiRequest("POST", "/api/auth/logout");
  },
};
