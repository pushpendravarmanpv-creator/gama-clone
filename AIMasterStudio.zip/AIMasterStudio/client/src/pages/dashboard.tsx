import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import { 
  Zap, 
  FileText, 
  Image, 
  Presentation, 
  BarChart3,
  TrendingUp,
  Book
} from "lucide-react";

export default function Dashboard() {
  const { data: stats } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: recentActivity } = useQuery({
    queryKey: ["/api/dashboard/activity"],
  });

  return (
    <div className="flex h-screen bg-muted/30">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Dashboard" />
        
        <main className="flex-1 overflow-y-auto p-6 bg-muted/20">
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 fade-in">
            <Card className="hover-lift" data-testid="stat-generations">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">AI Generations</p>
                    <p className="text-3xl font-bold text-foreground">
                      {stats?.generations || 0}
                    </p>
                    <p className="text-sm text-accent mt-1">+12% from last month</p>
                  </div>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Zap className="w-6 h-6 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover-lift" data-testid="stat-presentations">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Presentations</p>
                    <p className="text-3xl font-bold text-foreground">
                      {stats?.presentations || 0}
                    </p>
                    <p className="text-sm text-accent mt-1">+8% from last month</p>
                  </div>
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <Presentation className="w-6 h-6 text-accent" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover-lift" data-testid="stat-images">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Images Created</p>
                    <p className="text-3xl font-bold text-foreground">
                      {stats?.images || 0}
                    </p>
                    <p className="text-sm text-accent mt-1">+23% from last month</p>
                  </div>
                  <div className="w-12 h-12 bg-secondary/20 rounded-lg flex items-center justify-center">
                    <Image className="w-6 h-6 text-secondary-foreground" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover-lift" data-testid="stat-api-usage">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">API Usage</p>
                    <p className="text-3xl font-bold text-foreground">
                      {stats?.apiUsage || 0}%
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">of monthly limit</p>
                  </div>
                  <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-destructive" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Quick Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* AI Text Generation */}
            <Card className="hover-lift fade-in">
              <CardHeader>
                <CardTitle className="flex items-center space-x-4">
                  <div className="w-12 h-12 gradient-bg rounded-lg flex items-center justify-center">
                    <FileText className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">AI Text Generation</h3>
                    <p className="text-muted-foreground">Generate high-quality content with GPT-4</p>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea 
                  placeholder="Enter your prompt here..." 
                  rows={4} 
                  className="resize-none"
                  data-testid="input-quick-text-prompt"
                />
                
                <div className="flex items-center justify-between">
                  <Select defaultValue="creative">
                    <SelectTrigger className="w-40" data-testid="select-quick-text-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="creative">Creative Writing</SelectItem>
                      <SelectItem value="business">Business Content</SelectItem>
                      <SelectItem value="technical">Technical Documentation</SelectItem>
                      <SelectItem value="marketing">Marketing Copy</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  <Link href="/ai-text">
                    <Button className="gradient-bg" data-testid="button-quick-generate-text">
                      Generate
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
            
            {/* AI Image Generation */}
            <Card className="hover-lift fade-in">
              <CardHeader>
                <CardTitle className="flex items-center space-x-4">
                  <div className="w-12 h-12 gradient-bg rounded-lg flex items-center justify-center">
                    <Image className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold">AI Image Generation</h3>
                    <p className="text-muted-foreground">Create stunning images with DALL-E & Stability AI</p>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea 
                  placeholder="Describe the image you want to create..." 
                  rows={4} 
                  className="resize-none"
                  data-testid="input-quick-image-prompt"
                />
                
                <div className="flex items-center justify-between">
                  <div className="flex space-x-4">
                    <Select defaultValue="openai">
                      <SelectTrigger className="w-32" data-testid="select-quick-image-provider">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="openai">DALL-E 3</SelectItem>
                        <SelectItem value="stability">Stability AI</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select defaultValue="1024x1024">
                      <SelectTrigger className="w-32" data-testid="select-quick-image-size">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1024x1024">1024×1024</SelectItem>
                        <SelectItem value="1024x1792">1024×1792</SelectItem>
                        <SelectItem value="1792x1024">1792×1024</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Link href="/ai-image">
                    <Button className="gradient-bg" data-testid="button-quick-generate-image">
                      Generate
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Recent Activity & Templates */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Recent Activity */}
            <div className="lg:col-span-2">
              <Card className="fade-in">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Recent Activity</CardTitle>
                  <Button variant="ghost" size="sm" data-testid="button-view-all-activity">
                    View all
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivity?.length > 0 ? (
                      recentActivity.map((activity: any, index: number) => (
                        <div key={index} className="flex items-start space-x-4 p-4 rounded-lg hover:bg-muted/50 transition-colors">
                          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                            <FileText className="w-5 h-5 text-primary" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-foreground">{activity.title}</p>
                            <p className="text-xs text-muted-foreground">{activity.timestamp}</p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>No recent activity</p>
                        <p className="text-sm">Start generating content to see your activity here</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Quick Start Templates */}
            <Card className="fade-in">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Quick Start</CardTitle>
                <Button variant="ghost" size="sm" data-testid="button-browse-templates">
                  Browse all
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Link href="/presentations?template=business">
                    <div className="p-4 rounded-lg border border-border hover:border-primary/50 cursor-pointer transition-colors">
                      <div className="w-full h-20 bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg mb-3 flex items-center justify-center">
                        <BarChart3 className="w-8 h-8 text-primary" />
                      </div>
                      <p className="text-sm font-medium text-foreground">Business Presentation</p>
                      <p className="text-xs text-muted-foreground">Professional slides for business meetings</p>
                    </div>
                  </Link>
                  
                  <Link href="/presentations?template=pitch">
                    <div className="p-4 rounded-lg border border-border hover:border-primary/50 cursor-pointer transition-colors">
                      <div className="w-full h-20 bg-gradient-to-br from-accent/20 to-secondary/20 rounded-lg mb-3 flex items-center justify-center">
                        <TrendingUp className="w-8 h-8 text-accent" />
                      </div>
                      <p className="text-sm font-medium text-foreground">Startup Pitch Deck</p>
                      <p className="text-xs text-muted-foreground">Investor-ready pitch presentations</p>
                    </div>
                  </Link>
                  
                  <Link href="/presentations?template=educational">
                    <div className="p-4 rounded-lg border border-border hover:border-primary/50 cursor-pointer transition-colors">
                      <div className="w-full h-20 bg-gradient-to-br from-destructive/20 to-primary/20 rounded-lg mb-3 flex items-center justify-center">
                        <Book className="w-8 h-8 text-destructive" />
                      </div>
                      <p className="text-sm font-medium text-foreground">Educational Content</p>
                      <p className="text-xs text-muted-foreground">Learning materials and tutorials</p>
                    </div>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
