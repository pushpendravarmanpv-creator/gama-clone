import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PaymentForm } from "@/components/subscription/payment-form";
import { UPIPayment } from "@/components/subscription/upi-payment";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, CreditCard, Smartphone } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

const plans = [
  {
    id: "free",
    name: "Free",
    price: 0,
    features: [
      "10 AI generations/month",
      "Basic templates",
      "Community support",
    ],
  },
  {
    id: "pro",
    name: "Pro",
    price: 29,
    popular: true,
    features: [
      "Unlimited AI generations",
      "Premium templates",
      "Priority support",
      "Export to PDF/PPTX",
      "Advanced analytics",
    ],
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 99,
    features: [
      "Everything in Pro",
      "Team collaboration",
      "Custom integrations",
      "Dedicated support",
      "SLA guarantees",
    ],
  },
];

export default function Subscription() {
  const { user } = useAuth();
  const { data: subscription } = useQuery({
    queryKey: ["/api/subscription"],
  });

  return (
    <div className="flex h-screen bg-muted/30">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Subscription" />
        
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Current Plan */}
          {user && (
            <Card className="fade-in">
              <CardHeader>
                <CardTitle>Current Plan</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="text-xl font-semibold capitalize">{user.plan} Plan</h3>
                      {user.plan === "pro" && (
                        <Badge className="bg-accent text-accent-foreground">Pro</Badge>
                      )}
                    </div>
                    <p className="text-muted-foreground">
                      {user.apiUsage} / {user.monthlyLimit} generations used this month
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold">
                      ${plans.find(p => p.id === user.plan)?.price || 0}
                    </p>
                    <p className="text-sm text-muted-foreground">/month</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Pricing Plans */}
          <Card className="fade-in">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl">Upgrade to Premium</CardTitle>
              <p className="text-muted-foreground">Unlock unlimited AI generations and advanced features</p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {plans.map((plan) => (
                  <Card 
                    key={plan.id}
                    className={`relative ${plan.popular ? 'border-2 border-primary' : ''} ${user?.plan === plan.id ? 'opacity-50' : ''}`}
                  >
                    {plan.popular && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                      </div>
                    )}
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        {plan.name}
                        {user?.plan === plan.id && (
                          <Badge variant="outline">Current</Badge>
                        )}
                      </CardTitle>
                      <div className="text-3xl font-bold">
                        ${plan.price}
                        <span className="text-sm font-normal text-muted-foreground">/month</span>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <ul className="space-y-2">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-center space-x-2 text-sm">
                            <Check className="w-4 h-4 text-accent" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                      
                      {user?.plan !== plan.id && plan.id !== "free" && (
                        <Button 
                          className="w-full"
                          variant={plan.popular ? "default" : "outline"}
                          data-testid={`button-upgrade-${plan.id}`}
                        >
                          {plan.id === "enterprise" ? "Contact Sales" : "Upgrade"}
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Payment Methods */}
          {user?.plan === "free" && (
            <Card className="fade-in">
              <CardHeader>
                <CardTitle>Choose Payment Method</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="stripe" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="stripe" className="flex items-center space-x-2">
                      <CreditCard className="w-4 h-4" />
                      <span>Credit Card</span>
                    </TabsTrigger>
                    <TabsTrigger value="upi" className="flex items-center space-x-2">
                      <Smartphone className="w-4 h-4" />
                      <span>UPI (India)</span>
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="stripe" className="mt-6">
                    <PaymentForm />
                  </TabsContent>
                  
                  <TabsContent value="upi" className="mt-6">
                    <UPIPayment />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </div>
  );
}
