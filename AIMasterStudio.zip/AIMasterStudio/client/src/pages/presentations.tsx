import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Presentation, Plus, Download, FileText } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const templates = [
  { id: "business", name: "Business Presentation", description: "Professional slides for business meetings" },
  { id: "pitch", name: "Startup Pitch Deck", description: "Investor-ready pitch presentations" },
  { id: "educational", name: "Educational Content", description: "Learning materials and tutorials" },
];

export default function Presentations() {
  const [newPresentationTitle, setNewPresentationTitle] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("business");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: presentations, isLoading } = useQuery({
    queryKey: ["/api/presentations"],
  });

  const createPresentation = useMutation({
    mutationFn: async (data: { title: string; template: string }) => {
      const response = await apiRequest("POST", "/api/presentations", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/presentations"] });
      setNewPresentationTitle("");
      toast({
        title: "Presentation Created",
        description: "Your new presentation is ready to edit!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create presentation",
        variant: "destructive",
      });
    },
  });

  const exportPresentation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("POST", `/api/presentations/${id}/export`);
      return response.blob();
    },
    onSuccess: (blob, id) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `presentation-${id}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast({
        title: "Export Complete",
        description: "Your presentation has been downloaded",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Export Failed",
        description: error.message || "Failed to export presentation",
        variant: "destructive",
      });
    },
  });

  const handleCreate = () => {
    if (!newPresentationTitle.trim()) {
      toast({
        title: "Title Required",
        description: "Please enter a title for your presentation",
        variant: "destructive",
      });
      return;
    }

    createPresentation.mutate({ 
      title: newPresentationTitle, 
      template: selectedTemplate 
    });
  };

  return (
    <div className="flex h-screen bg-muted/30">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Presentations" />
        
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Create New Presentation */}
          <Card className="fade-in">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Plus className="w-5 h-5" />
                <span>Create New Presentation</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input
                  placeholder="Presentation title..."
                  value={newPresentationTitle}
                  onChange={(e) => setNewPresentationTitle(e.target.value)}
                  data-testid="input-presentation-title"
                />
                
                <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                  <SelectTrigger data-testid="select-presentation-template">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Button 
                  onClick={handleCreate}
                  disabled={createPresentation.isPending}
                  className="gradient-bg"
                  data-testid="button-create-presentation"
                >
                  {createPresentation.isPending ? "Creating..." : "Create"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Presentations List */}
          <Card className="fade-in">
            <CardHeader>
              <CardTitle>Your Presentations</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                </div>
              ) : presentations?.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {presentations.map((presentation: any) => (
                    <Card 
                      key={presentation.id} 
                      className="hover-lift cursor-pointer"
                      data-testid={`card-presentation-${presentation.id}`}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                            <Presentation className="w-6 h-6 text-primary" />
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => exportPresentation.mutate(presentation.id)}
                            disabled={exportPresentation.isPending}
                            data-testid={`button-export-${presentation.id}`}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                        
                        <h3 className="font-semibold text-foreground mb-2">
                          {presentation.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          {templates.find(t => t.id === presentation.template)?.description}
                        </p>
                        
                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Updated {new Date(presentation.updatedAt).toLocaleDateString()}</span>
                          <span className="capitalize">{presentation.template}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <FileText className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No presentations yet</h3>
                  <p className="text-muted-foreground">Create your first AI-powered presentation above</p>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
