import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { TextGenerator } from "@/components/ai/text-generator";

export default function AIText() {
  return (
    <div className="flex h-screen bg-muted/30">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="AI Text Generation" />
        
        <main className="flex-1 overflow-y-auto p-6">
          <TextGenerator />
        </main>
      </div>
    </div>
  );
}
