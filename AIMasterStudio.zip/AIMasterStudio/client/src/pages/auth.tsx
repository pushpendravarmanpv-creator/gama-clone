import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GoogleAuth } from "@/components/auth/google-auth";
import { Zap } from "lucide-react";

export default function Auth() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <Card className="w-full max-w-md glass-card">
        <CardHeader className="text-center space-y-4">
          <div className="w-16 h-16 gradient-bg rounded-2xl flex items-center justify-center mx-auto">
            <Zap className="w-8 h-8 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold">Welcome to AI Master Studio</CardTitle>
            <p className="text-muted-foreground">Sign in to access your AI-powered workspace</p>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <GoogleAuth />
          
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-card text-muted-foreground">Professional AI Tools</span>
            </div>
          </div>
          
          <div className="text-center text-sm text-muted-foreground">
            Generate content, create presentations, and unlock the power of AI
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
