import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { ImageGenerator } from "@/components/ai/image-generator";

export default function AIImage() {
  return (
    <div className="flex h-screen bg-muted/30">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="AI Image Generation" />
        
        <main className="flex-1 overflow-y-auto p-6">
          <ImageGenerator />
        </main>
      </div>
    </div>
  );
}
