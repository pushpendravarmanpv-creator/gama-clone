import { useQuery } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, TrendingUp, Users, Zap } from "lucide-react";

export default function Analytics() {
  const { data: analytics, isLoading } = useQuery({
    queryKey: ["/api/analytics"],
  });

  return (
    <div className="flex h-screen bg-muted/30">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header title="Analytics" />
        
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 fade-in">
            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Generations</p>
                    <p className="text-3xl font-bold text-foreground">
                      {analytics?.totalGenerations || 0}
                    </p>
                    <p className="text-sm text-accent mt-1">+15% from last week</p>
                  </div>
                  <Zap className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Success Rate</p>
                    <p className="text-3xl font-bold text-foreground">
                      {analytics?.successRate || 0}%
                    </p>
                    <p className="text-sm text-accent mt-1">+2% from last week</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-accent" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Avg Response Time</p>
                    <p className="text-3xl font-bold text-foreground">
                      {analytics?.avgResponseTime || 0}s
                    </p>
                    <p className="text-sm text-accent mt-1">-0.5s from last week</p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-secondary-foreground" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">API Credits Used</p>
                    <p className="text-3xl font-bold text-foreground">
                      {analytics?.creditsUsed || 0}
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">this month</p>
                  </div>
                  <Users className="w-8 h-8 text-destructive" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Usage Breakdown */}
          <Card className="fade-in">
            <CardHeader>
              <CardTitle>Usage by Service</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
                </div>
              ) : analytics?.serviceBreakdown ? (
                <div className="space-y-4">
                  {analytics.serviceBreakdown.map((service: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-4 rounded-lg border">
                      <div className="flex items-center space-x-3">
                        <div className="w-4 h-4 rounded-full bg-primary"></div>
                        <span className="font-medium">{service.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">{service.count}</div>
                        <div className="text-sm text-muted-foreground">{service.percentage}%</div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BarChart3 className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>No analytics data available</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Performance */}
          <Card className="fade-in">
            <CardHeader>
              <CardTitle>Performance Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                <TrendingUp className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p>Performance charts will be displayed here</p>
                <p className="text-sm">Track your AI usage patterns and optimization opportunities</p>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
