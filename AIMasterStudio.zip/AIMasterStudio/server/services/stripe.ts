import Stripe from "stripe";
import { storage } from "../storage";
import { sendPaymentSuccessEmail, sendPlanUpgradeEmail } from "./email";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-08-27.basil",
});

const STRIPE_PRICE_ID = process.env.STRIPE_PRICE_ID;
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET;

export async function createSubscription(user: any) {
  try {
    // Check if user already has a subscription
    if (user.stripeSubscriptionId) {
      const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
      
      if (subscription.latest_invoice && typeof subscription.latest_invoice === 'object') {
        const invoice = subscription.latest_invoice as Stripe.Invoice;
        // @ts-ignore - payment_intent exists when expanded
        const paymentIntent = invoice.payment_intent as Stripe.PaymentIntent;
        if (paymentIntent?.client_secret) {
          return {
            subscriptionId: subscription.id,
            clientSecret: paymentIntent.client_secret,
          };
        }
      }
    }

    // Create or retrieve customer
    let customer;
    if (user.stripeCustomerId) {
      customer = await stripe.customers.retrieve(user.stripeCustomerId);
    } else {
      customer = await stripe.customers.create({
        email: user.email,
        name: user.firstName && user.lastName ? 
          `${user.firstName} ${user.lastName}` : user.username,
      });
      
      await storage.updateUser(user.id, { stripeCustomerId: customer.id });
    }

    // Create subscription
    const subscription = await stripe.subscriptions.create({
      customer: customer.id,
      items: [{
        price: STRIPE_PRICE_ID || "price_1234567890", // Fallback price ID
      }],
      payment_behavior: 'default_incomplete',
      expand: ['latest_invoice.payment_intent'],
    });

    // Update user with subscription info
    await storage.updateUserStripeInfo(user.id, customer.id, subscription.id);

    const latestInvoice = subscription.latest_invoice as Stripe.Invoice;
    // @ts-ignore - payment_intent exists when expanded
    const paymentIntent = latestInvoice.payment_intent as Stripe.PaymentIntent;

    return {
      subscriptionId: subscription.id,
      clientSecret: paymentIntent.client_secret,
    };
  } catch (error) {
    console.error("Stripe subscription creation error:", error);
    throw new Error("Failed to create subscription");
  }
}

export async function handleStripeWebhook(req: any, res: any) {
  if (!STRIPE_WEBHOOK_SECRET) {
    console.log("Stripe webhook secret not configured");
    return res.status(200).send("OK");
  }

  const sig = req.headers['stripe-signature'];
  
  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, STRIPE_WEBHOOK_SECRET);
    
    switch (event.type) {
      case 'invoice.payment_succeeded':
        await handlePaymentSucceeded(event.data.object as Stripe.Invoice);
        break;
      case 'customer.subscription.updated':
        await handleSubscriptionUpdated(event.data.object as Stripe.Subscription);
        break;
      case 'customer.subscription.deleted':
        await handleSubscriptionDeleted(event.data.object as Stripe.Subscription);
        break;
      default:
        console.log(`Unhandled event type: ${event.type}`);
    }
    
    res.status(200).send("OK");
  } catch (error) {
    console.error("Stripe webhook error:", error);
    res.status(400).send(`Webhook Error: ${error}`);
  }
}

async function handlePaymentSucceeded(invoice: Stripe.Invoice) {
  // @ts-ignore - subscription exists when expanded
  if (!invoice.customer || !invoice.subscription) return;
  
  try {
    // @ts-ignore - subscription exists when expanded
    const subscription = await stripe.subscriptions.retrieve(invoice.subscription as string);
    const customerResponse = await stripe.customers.retrieve(invoice.customer as string);
    
    if (typeof customerResponse === 'string' || customerResponse.deleted) return;
    
    const customer = customerResponse as Stripe.Customer;
    
    // Find user by Stripe customer ID
    const users = await storage.getUserByEmail(customer.email || "");
    if (!users) return;
    
    // Update user plan
    await storage.updateUser(users.id, { 
      plan: "pro",
      monthlyLimit: -1, // Unlimited for pro
    });
    
    // Send success email
    await sendPaymentSuccessEmail(
      customer.email || "",
      customer.name || users.username,
      "Pro"
    );
    
    console.log(`Payment succeeded for user ${users.id}`);
  } catch (error) {
    console.error("Error handling payment succeeded:", error);
  }
}

async function handleSubscriptionUpdated(subscription: Stripe.Subscription) {
  try {
    const customerResponse = await stripe.customers.retrieve(subscription.customer as string);
    
    if (typeof customerResponse === 'string' || customerResponse.deleted) return;
    
    const customer = customerResponse as Stripe.Customer;
    
    const users = await storage.getUserByEmail(customer.email || "");
    if (!users) return;
    
    const planMap: { [key: string]: string } = {
      "active": "pro",
      "canceled": "free",
      "past_due": "free",
    };
    
    const newPlan = planMap[subscription.status] || "free";
    const monthlyLimit = newPlan === "pro" ? -1 : 10;
    
    await storage.updateUser(users.id, { 
      plan: newPlan,
      monthlyLimit,
    });
    
    console.log(`Subscription updated for user ${users.id}: ${newPlan}`);
  } catch (error) {
    console.error("Error handling subscription updated:", error);
  }
}

async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  try {
    const customerResponse = await stripe.customers.retrieve(subscription.customer as string);
    
    if (typeof customerResponse === 'string' || customerResponse.deleted) return;
    
    const customer = customerResponse as Stripe.Customer;
    
    const users = await storage.getUserByEmail(customer.email || "");
    if (!users) return;
    
    await storage.updateUser(users.id, { 
      plan: "free",
      monthlyLimit: 10,
      stripeSubscriptionId: null,
    });
    
    console.log(`Subscription deleted for user ${users.id}`);
  } catch (error) {
    console.error("Error handling subscription deleted:", error);
  }
}
