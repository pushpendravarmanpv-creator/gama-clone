if (!process.env.STABILITY_API_KEY) {
  console.warn("STABILITY_API_KEY not set. Stability AI image generation will not work.");
}

export async function generateImage(prompt: string, size: string = "1024x1024"): Promise<string> {
  if (!process.env.STABILITY_API_KEY) {
    throw new Error("Stability AI API key not configured");
  }

  try {
    const [width, height] = size.split('x').map(Number);
    
    const response = await fetch("https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.STABILITY_API_KEY}`,
        "Accept": "application/json",
      },
      body: JSON.stringify({
        text_prompts: [
          {
            text: prompt,
            weight: 1,
          }
        ],
        cfg_scale: 7,
        height,
        width,
        steps: 30,
        samples: 1,
      }),
    });

    if (!response.ok) {
      throw new Error(`Stability AI API error: ${response.status}`);
    }

    const data = await response.json();
    
    if (!data.artifacts || data.artifacts.length === 0) {
      throw new Error("No image generated");
    }

    // Convert base64 to data URL
    const base64Image = data.artifacts[0].base64;
    return `data:image/png;base64,${base64Image}`;
  } catch (error) {
    console.error("Stability AI image generation error:", error);
    throw new Error("Failed to generate image with Stability AI");
  }
}
