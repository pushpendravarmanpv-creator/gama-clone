import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { storage } from "../storage";

// Only initialize Google OAuth strategy if credentials are available
if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use(
    new GoogleStrategy(
      {
        clientID: process.env.GOOGLE_CLIENT_ID,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        callbackURL: "/api/auth/google/callback",
      },
      async (accessToken: any, refreshToken: any, profile: any, done: any) => {
        try {
          let user = await storage.getUserByGoogleId(profile.id);
          
          if (!user) {
            // Check if user exists with same email
            user = await storage.getUserByEmail(profile.emails?.[0]?.value || "");
            
            if (user) {
              // Link Google account to existing user
              user = await storage.updateUser(user.id, { googleId: profile.id });
            } else {
              // Create new user
              user = await storage.createUser({
                email: profile.emails?.[0]?.value || "",
                username: profile.displayName || profile.emails?.[0]?.value?.split("@")[0] || "",
                firstName: profile.name?.givenName || null,
                lastName: profile.name?.familyName || null,
                avatarUrl: profile.photos?.[0]?.value || null,
                googleId: profile.id,
              });
            }
          }
          
          return done(null, user);
        } catch (error) {
          return done(error as Error, undefined);
        }
      }
    )
  );
} else {
  console.warn("Missing Google OAuth credentials. Google authentication will not work.");
}

passport.serializeUser((user: any, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id: string, done) => {
  try {
    const user = await storage.getUser(id);
    done(null, user);
  } catch (error) {
    done(error, null);
  }
});

export { passport };
