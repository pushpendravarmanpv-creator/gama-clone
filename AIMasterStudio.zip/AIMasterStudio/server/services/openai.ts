import OpenAI from "openai";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY environment variable must be set");
}

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
});

export async function generateText(prompt: string, type: string): Promise<string> {
  try {
    const systemPrompts = {
      creative: "You are a creative writing assistant. Generate engaging, imaginative content.",
      business: "You are a business writing expert. Generate professional, clear, and actionable content.",
      technical: "You are a technical documentation specialist. Generate precise, accurate, and well-structured content.",
      marketing: "You are a marketing copywriter. Generate compelling, persuasive, and conversion-focused content.",
    };

    const response = await openai.chat.completions.create({
      // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: systemPrompts[type as keyof typeof systemPrompts] || systemPrompts.creative,
        },
        {
          role: "user",
          content: prompt,
        },
      ],
    });

    return response.choices[0].message.content || "";
  } catch (error) {
    console.error("OpenAI text generation error:", error);
    throw new Error("Failed to generate text");
  }
}

export async function generateImage(prompt: string, size: string = "1024x1024"): Promise<string> {
  try {
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt,
      n: 1,
      size: size as "1024x1024" | "1024x1792" | "1792x1024",
      quality: "standard",
    });

    return response.data[0].url || "";
  } catch (error) {
    console.error("OpenAI image generation error:", error);
    throw new Error("Failed to generate image");
  }
}
