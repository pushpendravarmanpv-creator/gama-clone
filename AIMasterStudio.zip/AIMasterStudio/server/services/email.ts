import { MailService } from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  console.warn("SENDGRID_API_KEY not set. Email notifications will not work.");
}

const mailService = new MailService();
if (process.env.SENDGRID_API_KEY) {
  mailService.setApiKey(process.env.SENDGRID_API_KEY);
}

const FROM_EMAIL = process.env.FROM_EMAIL || "noreply@aimasterstudio.com";

export async function sendWelcomeEmail(to: string, name: string): Promise<boolean> {
  if (!process.env.SENDGRID_API_KEY) {
    console.log("Would send welcome email to:", to);
    return true;
  }

  try {
    await mailService.send({
      to,
      from: FROM_EMAIL,
      subject: "Welcome to AI Master Studio!",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #7c3aed;">Welcome to AI Master Studio!</h1>
          <p>Hi ${name},</p>
          <p>Welcome to AI Master Studio! You now have access to powerful AI tools for content generation, image creation, and presentation building.</p>
          <p>Get started by:</p>
          <ul>
            <li>Generating your first AI content</li>
            <li>Creating stunning images with DALL-E</li>
            <li>Building professional presentations</li>
          </ul>
          <p>If you have any questions, feel free to reach out to our support team.</p>
          <p>Best regards,<br>The AI Master Studio Team</p>
        </div>
      `,
    });
    return true;
  } catch (error) {
    console.error("Failed to send welcome email:", error);
    return false;
  }
}

export async function sendPaymentSuccessEmail(to: string, name: string, plan: string): Promise<boolean> {
  if (!process.env.SENDGRID_API_KEY) {
    console.log("Would send payment success email to:", to);
    return true;
  }

  try {
    await mailService.send({
      to,
      from: FROM_EMAIL,
      subject: "Payment Successful - Welcome to Pro!",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #7c3aed;">Payment Successful!</h1>
          <p>Hi ${name},</p>
          <p>Thank you for upgrading to the ${plan} plan! Your payment has been processed successfully.</p>
          <p>You now have access to:</p>
          <ul>
            <li>Unlimited AI generations</li>
            <li>Premium templates</li>
            <li>Priority support</li>
            <li>Export to PDF/PPTX</li>
          </ul>
          <p>Start creating amazing content with your new Pro features!</p>
          <p>Best regards,<br>The AI Master Studio Team</p>
        </div>
      `,
    });
    return true;
  } catch (error) {
    console.error("Failed to send payment success email:", error);
    return false;
  }
}

export async function sendPlanUpgradeEmail(to: string, name: string, plan: string): Promise<boolean> {
  if (!process.env.SENDGRID_API_KEY) {
    console.log("Would send plan upgrade email to:", to);
    return true;
  }

  try {
    await mailService.send({
      to,
      from: FROM_EMAIL,
      subject: "Plan Upgraded Successfully!",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #7c3aed;">Plan Upgraded!</h1>
          <p>Hi ${name},</p>
          <p>Your account has been successfully upgraded to the ${plan} plan!</p>
          <p>Enjoy your enhanced AI Master Studio experience with unlimited access to all our premium features.</p>
          <p>If you have any questions about your new plan, don't hesitate to contact us.</p>
          <p>Best regards,<br>The AI Master Studio Team</p>
        </div>
      `,
    });
    return true;
  } catch (error) {
    console.error("Failed to send plan upgrade email:", error);
    return false;
  }
}
