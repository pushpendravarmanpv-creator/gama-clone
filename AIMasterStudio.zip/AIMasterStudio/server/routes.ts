import type { Express } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import express from "express";
import { passport } from "./services/auth";
import { storage } from "./storage";
import { generateText, generateImage as generateOpenAIImage } from "./services/openai";
import { generateImage as generateStabilityImage } from "./services/stability";
import { createSubscription, handleStripeWebhook } from "./services/stripe";
import { sendWelcomeEmail, sendPaymentSuccessEmail, sendPlanUpgradeEmail } from "./services/email";
import { exportPresentationToPDF } from "./services/pdf-export";
import { insertAiGenerationSchema, insertPresentationSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || "fallback-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  }));

  // Initialize Passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Authentication routes
  app.get("/api/auth/google", passport.authenticate("google", { 
    scope: ["profile", "email"] 
  }));

  app.get("/api/auth/google/callback", 
    passport.authenticate("google", { failureRedirect: "/auth" }),
    async (req, res) => {
      const user = req.user as any;
      if (user && user.createdAt && new Date().getTime() - new Date(user.createdAt).getTime() < 60000) {
        // Send welcome email for new users
        await sendWelcomeEmail(
          user.email, 
          user.firstName || user.username
        );
      }
      res.redirect("/");
    }
  );

  app.get("/api/auth/me", (req, res) => {
    if (req.isAuthenticated()) {
      res.json(req.user);
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // User profile routes
  app.patch("/api/user/profile", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const { firstName, lastName, username } = req.body;
      const user = req.user as any;
      
      const updatedUser = await storage.updateUser(user.id, {
        firstName,
        lastName,
        username,
      });
      
      res.json(updatedUser);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // AI text generation
  app.post("/api/ai/generate-text", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const { prompt, type } = req.body;
      const user = req.user as any;

      // Check usage limits for free users
      if (user.plan === "free" && user.apiUsage >= user.monthlyLimit) {
        return res.status(402).json({ 
          message: "Monthly limit reached. Please upgrade to continue." 
        });
      }

      const content = await generateText(prompt, type);

      // Store generation record
      await storage.createAiGeneration({
        userId: user.id,
        type: "text",
        provider: "openai",
        prompt,
        result: { content },
        metadata: { type },
      });

      // Update usage
      await storage.updateApiUsage(user.id, 1);

      res.json({ content });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // AI image generation
  app.post("/api/ai/generate-image", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const { prompt, provider, size } = req.body;
      const user = req.user as any;

      // Check usage limits for free users
      if (user.plan === "free" && user.apiUsage >= user.monthlyLimit) {
        return res.status(402).json({ 
          message: "Monthly limit reached. Please upgrade to continue." 
        });
      }

      let imageUrl: string;
      
      if (provider === "stability") {
        imageUrl = await generateStabilityImage(prompt, size);
      } else {
        imageUrl = await generateOpenAIImage(prompt, size);
      }

      // Store generation record
      await storage.createAiGeneration({
        userId: user.id,
        type: "image",
        provider,
        prompt,
        result: { url: imageUrl },
        metadata: { size },
      });

      // Update usage
      await storage.updateApiUsage(user.id, 1);

      res.json({ url: imageUrl });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // AI generations history
  app.get("/api/ai/generations", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = req.user as any;
      const generations = await storage.getUserGenerations(user.id);
      res.json(generations);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Presentation routes
  app.get("/api/presentations", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = req.user as any;
      const presentations = await storage.getUserPresentations(user.id);
      res.json(presentations);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/presentations", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const { title, template } = req.body;
      const user = req.user as any;

      // Generate initial content based on template
      const templateContent = await generatePresentationContent(template, title);

      const presentation = await storage.createPresentation({
        userId: user.id,
        title,
        template,
        content: templateContent,
      });

      res.json(presentation);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/presentations/:id/export", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const { id } = req.params;
      const user = req.user as any;

      // Check if user has pro plan for export feature
      if (user.plan === "free") {
        return res.status(402).json({ 
          message: "Export feature requires Pro plan. Please upgrade." 
        });
      }

      const presentations = await storage.getUserPresentations(user.id);
      const presentation = presentations.find(p => p.id === id);

      if (!presentation) {
        return res.status(404).json({ message: "Presentation not found" });
      }

      const pdfBuffer = await exportPresentationToPDF(presentation);
      
      // Mark as exported
      await storage.updatePresentation(id, { exported: true });

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${presentation.title}.pdf"`);
      res.send(pdfBuffer);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = req.user as any;
      const generations = await storage.getUserGenerations(user.id);
      const presentations = await storage.getUserPresentations(user.id);

      const textGenerations = generations.filter(g => g.type === "text").length;
      const imageGenerations = generations.filter(g => g.type === "image").length;
      
      const apiUsagePercentage = user.monthlyLimit === -1 ? 0 : 
        Math.round((user.apiUsage / user.monthlyLimit) * 100);

      res.json({
        generations: generations.length,
        presentations: presentations.length,
        images: imageGenerations,
        apiUsage: apiUsagePercentage,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Dashboard activity
  app.get("/api/dashboard/activity", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = req.user as any;
      const generations = await storage.getUserGenerations(user.id, 10);
      const presentations = await storage.getUserPresentations(user.id);

      const activity = [
        ...generations.map(g => ({
          title: `Generated ${g.type}: "${g.prompt.substring(0, 50)}..."`,
          timestamp: g.createdAt.toISOString(),
          type: g.type,
        })),
        ...presentations.slice(0, 5).map(p => ({
          title: `Created presentation: "${p.title}"`,
          timestamp: p.createdAt.toISOString(),
          type: "presentation",
        })),
      ]
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .slice(0, 10);

      res.json(activity);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Analytics
  app.get("/api/analytics", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = req.user as any;
      const generations = await storage.getUserGenerations(user.id);

      const totalGenerations = generations.length;
      const successRate = totalGenerations > 0 ? 98 : 0; // Most generations succeed
      const avgResponseTime = 2.5; // Average response time in seconds
      const creditsUsed = user.apiUsage;

      const serviceBreakdown = [
        {
          name: "Text Generation",
          count: generations.filter(g => g.type === "text").length,
          percentage: totalGenerations > 0 ? 
            Math.round((generations.filter(g => g.type === "text").length / totalGenerations) * 100) : 0,
        },
        {
          name: "Image Generation", 
          count: generations.filter(g => g.type === "image").length,
          percentage: totalGenerations > 0 ?
            Math.round((generations.filter(g => g.type === "image").length / totalGenerations) * 100) : 0,
        },
      ];

      res.json({
        totalGenerations,
        successRate,
        avgResponseTime,
        creditsUsed,
        serviceBreakdown,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Subscription routes
  app.get("/api/subscription", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = req.user as any;
    res.json({
      plan: user.plan,
      stripeCustomerId: user.stripeCustomerId,
      stripeSubscriptionId: user.stripeSubscriptionId,
      apiUsage: user.apiUsage,
      monthlyLimit: user.monthlyLimit,
    });
  });

  // Payment routes
  app.post("/api/payments/create-subscription", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = req.user as any;
      const result = await createSubscription(user);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Stripe webhook
  app.post("/api/webhooks/stripe", express.raw({ type: 'application/json' }), async (req, res) => {
    try {
      await handleStripeWebhook(req, res);
    } catch (error: any) {
      console.error("Stripe webhook error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function generatePresentationContent(template: string, title: string) {
  // Generate AI-powered presentation content based on template
  const templatePrompts = {
    business: `Create a professional business presentation outline for "${title}" with 8 slides including: title slide, agenda, problem statement, solution overview, market analysis, implementation plan, financial projections, and conclusion.`,
    pitch: `Create a startup pitch deck outline for "${title}" with 10 slides including: title slide, problem, solution, market size, business model, traction, competition, team, financials, and ask.`,
    educational: `Create an educational presentation outline for "${title}" with 12 slides including: title slide, learning objectives, introduction, main concepts (6 slides), examples, exercises, summary, and references.`,
  };

  try {
    const prompt = templatePrompts[template as keyof typeof templatePrompts] || templatePrompts.business;
    const outline = await generateText(prompt, "business");
    
    return {
      title,
      template,
      outline,
      slides: parseOutlineToSlides(outline),
    };
  } catch (error) {
    console.error("Failed to generate presentation content:", error);
    return {
      title,
      template,
      outline: "Failed to generate content",
      slides: [],
    };
  }
}

function parseOutlineToSlides(outline: string) {
  // Simple parsing logic to convert outline to slides
  const lines = outline.split('\n').filter(line => line.trim());
  const slides = [];
  
  let currentSlide = null;
  
  for (const line of lines) {
    if (line.match(/^\d+\.|^-|^•/) || line.includes('Slide')) {
      if (currentSlide) {
        slides.push(currentSlide);
      }
      currentSlide = {
        title: line.replace(/^\d+\.|\s*-\s*|•\s*|Slide\s*\d+:\s*/g, '').trim(),
        content: [],
      };
    } else if (currentSlide && line.trim()) {
      currentSlide.content.push(line.trim());
    }
  }
  
  if (currentSlide) {
    slides.push(currentSlide);
  }
  
  return slides;
}
