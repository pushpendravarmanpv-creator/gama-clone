import { type User, type InsertUser, type AiGeneration, type InsertAiGeneration, type Presentation, type InsertPresentation } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<User>): Promise<User>;
  updateUserStripeInfo(id: string, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User>;
  
  // AI Generation operations
  createAiGeneration(generation: InsertAiGeneration): Promise<AiGeneration>;
  getUserGenerations(userId: string, limit?: number): Promise<AiGeneration[]>;
  updateApiUsage(userId: string, increment: number): Promise<void>;
  
  // Presentation operations
  createPresentation(presentation: InsertPresentation): Promise<Presentation>;
  getUserPresentations(userId: string): Promise<Presentation[]>;
  updatePresentation(id: string, data: Partial<Presentation>): Promise<Presentation>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private aiGenerations: Map<string, AiGeneration>;
  private presentations: Map<string, Presentation>;

  constructor() {
    this.users = new Map();
    this.aiGenerations = new Map();
    this.presentations = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.googleId === googleId);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const now = new Date();
    const user: User = { 
      id,
      email: insertUser.email,
      username: insertUser.username,
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      avatarUrl: insertUser.avatarUrl || null,
      plan: insertUser.plan || "free",
      stripeCustomerId: insertUser.stripeCustomerId || null,
      stripeSubscriptionId: insertUser.stripeSubscriptionId || null,
      googleId: insertUser.googleId || null,
      apiUsage: insertUser.apiUsage || 0,
      monthlyLimit: insertUser.monthlyLimit || 10,
      createdAt: now,
      updatedAt: now,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, data: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) {
      throw new Error("User not found");
    }
    
    const updatedUser: User = { 
      ...user, 
      ...data, 
      updatedAt: new Date() 
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserStripeInfo(id: string, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User> {
    return this.updateUser(id, { 
      stripeCustomerId, 
      stripeSubscriptionId,
      plan: "pro",
      monthlyLimit: -1 // Unlimited for pro
    });
  }

  async createAiGeneration(insertGeneration: InsertAiGeneration): Promise<AiGeneration> {
    const id = randomUUID();
    const generation: AiGeneration = {
      id,
      userId: insertGeneration.userId,
      type: insertGeneration.type,
      provider: insertGeneration.provider,
      prompt: insertGeneration.prompt,
      result: insertGeneration.result || null,
      metadata: insertGeneration.metadata || null,
      createdAt: new Date(),
    };
    this.aiGenerations.set(id, generation);
    return generation;
  }

  async getUserGenerations(userId: string, limit = 50): Promise<AiGeneration[]> {
    return Array.from(this.aiGenerations.values())
      .filter(generation => generation.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
  }

  async updateApiUsage(userId: string, increment: number): Promise<void> {
    const user = this.users.get(userId);
    if (user) {
      user.apiUsage += increment;
      this.users.set(userId, user);
    }
  }

  async createPresentation(insertPresentation: InsertPresentation): Promise<Presentation> {
    const id = randomUUID();
    const now = new Date();
    const presentation: Presentation = {
      ...insertPresentation,
      id,
      exported: false,
      createdAt: now,
      updatedAt: now,
    };
    this.presentations.set(id, presentation);
    return presentation;
  }

  async getUserPresentations(userId: string): Promise<Presentation[]> {
    return Array.from(this.presentations.values())
      .filter(presentation => presentation.userId === userId)
      .sort((a, b) => (b.updatedAt?.getTime() || 0) - (a.updatedAt?.getTime() || 0));
  }

  async updatePresentation(id: string, data: Partial<Presentation>): Promise<Presentation> {
    const presentation = this.presentations.get(id);
    if (!presentation) {
      throw new Error("Presentation not found");
    }
    
    const updatedPresentation: Presentation = {
      ...presentation,
      ...data,
      updatedAt: new Date(),
    };
    this.presentations.set(id, updatedPresentation);
    return updatedPresentation;
  }
}

export const storage = new MemStorage();
