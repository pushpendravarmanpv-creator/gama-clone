import { Request, Response, NextFunction } from "express";

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Authentication required" });
  }
  next();
}

export function requirePlan(plan: string) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }

    const user = req.user as any;
    if (user.plan !== plan && plan !== "free") {
      return res.status(402).json({ 
        message: `${plan} plan required for this feature` 
      });
    }
    
    next();
  };
}

export function checkUsageLimit(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Authentication required" });
  }

  const user = req.user as any;
  
  // Pro users have unlimited usage
  if (user.plan === "pro" || user.plan === "enterprise") {
    return next();
  }

  // Check free tier limits
  if (user.apiUsage >= user.monthlyLimit) {
    return res.status(402).json({ 
      message: "Monthly usage limit reached. Please upgrade to continue.",
      currentUsage: user.apiUsage,
      limit: user.monthlyLimit
    });
  }

  next();
}
